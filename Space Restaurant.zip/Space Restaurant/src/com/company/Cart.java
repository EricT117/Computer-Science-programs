package com.company;

import java.util.ArrayList;

public class Cart{
  private static ArrayList<Product> cart = new ArrayList<Product>();
  private double total;
  
  //Adds item to the cart.
  public void addItem(Products m, int id){
    cart.add(m.getItem(id));
  }
  //Removes item from the cart.
  public void removeItem(Products m, int i){
    cart.remove(m.getItem(i));
  }
  //Retrieves item from the cart.
  public static String retrieveItem(Products m, int id){
    return m.getItem(id).foodName();
  }
  //prints out all ordered food items
  public void printCart(){
    System.out.println("Your Cart:");
    for (Product p : cart){
      System.out.print("#" + p.foodId() + " " + p.foodName() + " - $");
      System.out.printf("%.2f", p.foodPrice());
      System.out.println("");
    }
    System.out.print("Current Total: $");
    System.out.printf("%.2f", calculateTotal());
    System.out.println("");
  }

//sums the prices of all items in cart
  public double calculateTotal(){
      double total = 0;
      for (Product p : cart){
       total += p.foodPrice();
    }
    
    return total;
  }

  //return cart ArrayList
  public static ArrayList<Product> getCart(){
    return cart;
  }
}