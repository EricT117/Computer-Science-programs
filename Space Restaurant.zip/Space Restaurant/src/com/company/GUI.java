package com.company;

import javafx.scene.control.ComboBox;
import javafx.scene.layout.GridPane;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class GUI implements ActionListener {
    JFrame frame;
    ImageIcon image;
    JLabel titleName;
    JButton menuButton;
    JButton button;
    JPanel buttonPanel;
    JComboBox cartBox;
    Products products1 = new Products();
    Cart cart1 = new Cart();

    //UI uiClass = new UI();
    JButton menuItem1;
    JTabbedPane menuPane;
    JPanel menuPanel;
    ArrayList<Products> menuList;
    ArrayList<JButton> buttonList;
    JPanel buttonPanel2;

    public GUI(){
        frame = new JFrame("Space Restaurant");
        image = new ImageIcon("img.png");
        titleName = new JLabel();
        buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.white);
        buttonPanel.setBounds(900, 500, 100, 50);
        frame.add(buttonPanel);
        titleName.setText("Welcome to our Space Restaurant");
        titleName.setHorizontalAlignment(JLabel.CENTER);
        titleName.setVerticalAlignment(JLabel.TOP);
        titleName.setForeground(new Color(0xFFFFFF));
        titleName.setFont(new Font("Abril Fatface", Font.PLAIN, 40 ));
        frame.add(titleName);
        menuButton = new JButton();

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1920,1080);
        frame.setVisible(true);
        frame.setIconImage(image.getImage());
        frame.getContentPane().setBackground(Color.black);

        menuButton.setBounds(150, 100, 100, 100);
        menuButton.setText("Open Menu");
        menuButton.addActionListener(this);
        buttonPanel.add(menuButton);





    }
    public void menuAndCart(){
        frame.dispose();
        JFrame menuPage = new JFrame("Menu and Cart");
        menuPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        menuPage.setSize(1920,1080);
        menuPage.setLayout(new BorderLayout());
        menuPage.setVisible(true);
        //frame.setIconImage(image.getImage());
        menuPage.getContentPane().setBackground(Color.black);
        JMenuBar menuBar = new JMenuBar();
        menuPane = new JTabbedPane();
        menuPanel = new JPanel();
        menuPanel.setBounds(0,0, 300, 300);
        menuList = new ArrayList<Products>();
        buttonList = new ArrayList<JButton>();
        products1.initFoodItems(menuList);
        cartBox = new JComboBox();
        cartBox.setBounds(0, 500, 300, 300);



        menuPane.add(menuPanel);
        menuPane.addTab("Menu", menuPanel);
        menuPane.add(menuPanel);
        buttonPanel2 = new JPanel(new GridLayout(0, 1));
        menuPanel.add(makeButtons(products1));
        menuPanel.add(buttonPanel2);
        menuPane.setVisible(true);
        menuPage.add(menuPane);
        menuPanel.add(cartBox);

    }

    public JPanel makeButtons(Products product){
        for(int i = 0; i < product.getMenu().size(); i++){
            ArrayList <Product> temp = product.getMenu();
            button = new JButton(temp.get(i).foodName());
            button.setBounds(0, i * 50, 100, 50);
            buttonPanel2.add(button);
        }
        return buttonPanel2;
    }

    public void addToCart(){
        cartBox.add(cart1.addItem(products1,button));

    }


    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        if(actionEvent.getSource() == menuButton){
            menuAndCart();
        }

        if(actionEvent.getSource() == menuItem1){

        }

        /*if(actionEvent.getSource() == button){
            cart1.addItem(button, button.foodId);
        }
        */
        if(actionEvent.getSource() == cartBox){
            cart1.getCart();
        }

    }
}
