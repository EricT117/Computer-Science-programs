package com.company;

import java.util.Objects;
public class Product{
  private String foodName;
  private int foodId;
  private double foodPrice;
  private int foodQuantity;
  
  public Product(String foodName, int foodId, double foodPrice, int foodQuantity){
    this.foodName = foodName;
    this.foodId = foodId;
    this.foodPrice = foodPrice;
    this.foodQuantity = foodQuantity;
  }
  //Returns the food name.
  public String foodName(){
    return foodName;
  }
  //Returns the food ID.
  public int foodId(){
    return foodId;
  }
  //Returns the price of the food.
  public double foodPrice(){
    return foodPrice;
  }
  //Updates the quantity.
  public void quantityUpdate(){
    foodQuantity++;
  }



@Override
public int hashCode(){
//To-Do together
int hash = 13;
hash = 13 * hash + Objects.hashCode(this.foodName);
hash = 13 * hash + Objects.hashCode(this.foodId);
hash = 13 * hash + Objects.hashCode(this.foodPrice);
hash = 13 * hash + Objects.hashCode(this.foodQuantity);
return hash;
}

@Override
public boolean equals(Object obj){
  //To-Do together
  if(this == obj){
    return true;
  }
  if(obj == null){
    return false;
  }
  if(getClass() != obj.getClass()){
  return false;
  }
  final Product other = (Product) obj;
  if(!Objects.equals(this.foodName, other.foodName)){
    return false;
  }
  if(!Objects.equals(this.foodId, other.foodId)){
    return false;
  }
  if(!Objects.equals(this.foodPrice, other.foodPrice)){
    return false;
  }
  if(!Objects.equals(this.foodQuantity, other.foodQuantity)){
    return false;
  }
  return true;
}








  
}