package com.company;

import java.util.ArrayList;

public class Products{
  private ArrayList<Product> menu = new ArrayList<Product>();
  
  public Products(){
    //Call initFoodItems here
    initFoodItems();
  }

  //returns an item from the menu based on ID
  public Product getItem(int id){
    return menu.get(id);
  }

  public ArrayList getMenu(){
    return menu;
  }
  
  //prints the menu out for the user
  public void printMenu(){
    int i = 0;
    for (Product p : menu){
      System.out.print(i + ". " + p.foodName() + " - $");
      System.out.printf("%.2f", p.foodPrice());
      System.out.println("");
      i++;
    }
  }

  //adds all the food items to the menu
  private void initFoodItems(){
    menu.add(new Product("Sun Lava Cake", 0, 11, 2));
    menu.add(new Product("Mercury Macaron", 1, 2.50, 12));
    menu.add(new Product("Venus Vanilla Ice Cream", 2, 2, 10));
    menu.add(new Product("Earth Eclair", 3, 5.75, 8));
    menu.add(new Product("Mars Mug Cake", 4, 4.25, 4));
    menu.add(new Product("Jupiter Jam Donut", 5, 1.50, 12));
    menu.add(new Product("Saturn Shortcake", 6, 9, 3));
    menu.add(new Product("Uranus Upside-down Cake", 7, 6.50, 2));
    menu.add(new Product("Neptune Nutella Crepes", 8, 8.50, 5));
    menu.add(new Product("Pluto Cake Pop", 9, 1.75, 10));
    menu.add(new Product("Moon Mint Chocolate Ice Cream", 10, 2, 10));
    menu.add(new Product("Halle's Hotcakes", 11, 3.75, 6));
    menu.add(new Product("Comet Cookie", 12, .75, 12));
    menu.add(new Product("Rocket Cake", 13, 20, 1));
  }

  public void initFoodItems(ArrayList list){
    menu.add(new Product("Sun Lava Cake", 0, 11, 2));
    menu.add(new Product("Mercury Macaron", 1, 2.50, 12));
    menu.add(new Product("Venus Vanilla Ice Cream", 2, 2, 10));
    menu.add(new Product("Earth Eclair", 3, 5.75, 8));
    menu.add(new Product("Mars Mug Cake", 4, 4.25, 4));
    menu.add(new Product("Jupiter Jam Donut", 5, 1.50, 12));
    menu.add(new Product("Saturn Shortcake", 6, 9, 3));
    menu.add(new Product("Uranus Upside-down Cake", 7, 6.50, 2));
    menu.add(new Product("Neptune Nutella Crepes", 8, 8.50, 5));
    menu.add(new Product("Pluto Cake Pop", 9, 1.75, 10));
    menu.add(new Product("Moon Mint Chocolate Ice Cream", 10, 2, 10));
    menu.add(new Product("Halle's Hotcakes", 11, 3.75, 6));
    menu.add(new Product("Comet Cookie", 12, .75, 12));
    menu.add(new Product("Rocket Cake", 13, 20, 1));
  }
}