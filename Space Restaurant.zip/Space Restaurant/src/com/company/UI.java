package com.company;

import java.util.Scanner;
public class UI{
  private Cart cart = new Cart();
  private Scanner scan = new Scanner(System.in);
  private Products menu = new Products();

  public UI(){
    System.out.println("Welcome to our Space Restaurant!");
    //starts an order, then repeats a menu of actions until checkout
    orderItem();
    while (true){  
      System.out.println("What would you like to do next? \n1. Add another item \n2. View cart \n3. Checkout");
      String choice = scan.nextLine();
      if (choice.equals("1") || choice.toLowerCase().equals("add another item")){
        orderItem();
      }
      else if (choice.equals("2") || choice.toLowerCase().equals("view cart")){
        viewCart();
      }
      else if (choice.equals("3") || choice.toLowerCase().equals("checkout")){
        checkout();
        break;
      }
      else{
        System.out.println("I don't understand, can you try again?");
      }
    }
    scan.close();
  }

  public void orderItem(){
    while(true){
      System.out.println("Please select your item. ");
      menu.printMenu();
      //tries to get an int from the user
      try{
        int choice = scan.nextInt();
        //Clear scanner buffer after getting an int or boolean
        scan.nextLine();
        //checks if item is on the menu before adding it to cart
        if (choice <= 13 && choice >= 0){
          cart.addItem(menu, choice);
          System.out.println("Your item has been added to the cart!");
          break;
        }
        else{
          System.out.println("Sorry, that's not on our menu, can you try again?");
        }
      }
      //catches if they enter a non-integer and loops back to the try
      catch (Exception e){
        System.out.println("Make sure to enter the ID # of the item you want.");
        scan.next();
      }
    }
  }

  public void remItem(){
    while (true){
      System.out.println("What item are you removing?");
      Scanner rem = new Scanner(System.in);
      try{
        //Create a new scanner to deal with this?
        int choice2 = rem.nextInt();
        //checks if item is from the menu and in the cart to even remove
        if (cart.getCart().contains(menu.getItem(choice2))){
          cart.removeItem(menu, choice2);
          System.out.println("The item has been removed.");
          break;
        }
        else{
          System.out.println("That's not in your cart, try again.");
        }
      }
      catch(Exception e){
        System.out.println("Make sure to enter the ID # of the item you want to remove.");
        rem.next();
      }
      rem.close();
    }
  }

  // Let's the user view their cart.
  public void viewCart(){
    cart.printCart();
    System.out.println("Would you like to: \n1. Add an item \n2. Remove an item \n3. Return to menu \n4. Checkout");
    
    
    while (true){
      String choice = scan.nextLine();
      if (choice.equals("1") || choice.toLowerCase().equals("add an item")){
        orderItem();
        break;
      }
      else if (choice.equals("2") || choice.toLowerCase().equals("remove an item")){
        remItem();
        break;
      }
      else if (choice.equals("3") || choice.toLowerCase().equals("return to menu")){
        menu.printMenu();
        break;
      }
      else if (choice.equals("4") || choice.toLowerCase().equals("checkout")){
        checkout();
        System.exit(0);
      }
      else{
        System.out.println("I don't understand, can you try again?");
      }
    }
  }
  
  //Prints cart and tells the user the total amount spent.
  public void checkout(){
    cart.printCart();
    System.out.print("Your total is: $");
    System.out.printf("%.2f", cart.calculateTotal());
    System.out.println("");
    System.out.println("Thanks for shopping at our Restaurant! Have a good day!");
  }
}
