import java.util.Scanner;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class Main {
  public static void main(String[] args){
    Choice option = new Choice();

  }
}