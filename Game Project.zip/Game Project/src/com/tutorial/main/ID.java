package com.tutorial.main;

public enum ID {

    Player(),
    BasicEnemy(),
    Trail();
}
